UART/Src/pin_config.o: ../UART/Src/pin_config.c \
 /home/raghav/Desktop/Infotainment_System_New/GPS/GPS/UART/Inc/PIN_CONFIG.h \
 ../Inc/stm32f4xx.h ../Inc/stm32f407xx.h ../Inc/core_cm4.h \
 ../Inc/cmsis_version.h ../Inc/cmsis_compiler.h ../Inc/cmsis_gcc.h \
 ../Inc/mpu_armv7.h ../Inc/system_stm32f4xx.h ../Inc/stm32f407xx.h
/home/raghav/Desktop/Infotainment_System_New/GPS/GPS/UART/Inc/PIN_CONFIG.h:
../Inc/stm32f4xx.h:
../Inc/stm32f407xx.h:
../Inc/core_cm4.h:
../Inc/cmsis_version.h:
../Inc/cmsis_compiler.h:
../Inc/cmsis_gcc.h:
../Inc/mpu_armv7.h:
../Inc/system_stm32f4xx.h:
../Inc/stm32f407xx.h:
