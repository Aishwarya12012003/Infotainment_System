################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
CYCLO_FILES := 
SIZE_OUTPUT := 
OBJDUMP_LIST := 
SU_FILES := 
EXECUTABLES := 
OBJS := 
MAP_FILES := 
S_DEPS := 
S_UPPER_DEPS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
APDS/Src \
GPS/Src \
I2C/Src \
MCP2515_TX/Src \
SPI/Src \
Src \
Startup \
ThirdParty/FreeRTOS \
ThirdParty/FreeRTOS/portable/GCC/ARM_CM4F \
ThirdParty/FreeRTOS/portable/MemMang \
UART/Src \

